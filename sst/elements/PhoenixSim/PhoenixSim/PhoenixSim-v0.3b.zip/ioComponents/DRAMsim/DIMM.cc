#include "DIMM.h"


DIMM::DIMM(){


}
