#ifndef UTILITIES__H
#define UTILITIES__H





#include "Command.h"


void build_wave(char *buffer_string, int transaction_id, Command *this_c, int action);







#endif

