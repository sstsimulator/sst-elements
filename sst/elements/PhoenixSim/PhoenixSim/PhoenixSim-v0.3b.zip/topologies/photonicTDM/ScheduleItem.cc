

#include "ScheduleItem.h"


simtime_t ScheduleItem::cntrlPeriod;
int ScheduleItem::numWavelengths;
double ScheduleItem::dataRate;


int ScheduleItem_Mem::rows;
int ScheduleItem_Mem::cols;
int ScheduleItem_Mem::banks;
int ScheduleItem_Mem::chips;
int ScheduleItem_Mem::arrays;
