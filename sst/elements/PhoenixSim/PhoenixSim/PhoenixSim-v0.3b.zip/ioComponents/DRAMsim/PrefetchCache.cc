#include "PrefetchCache.h"



PrefetchCache::PrefetchCache(){


}