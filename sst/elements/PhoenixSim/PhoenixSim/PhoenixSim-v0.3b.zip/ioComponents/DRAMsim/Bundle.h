


class Bundle {

public:

	Bundle();


	int bundle_id;
	int bundle_type; /* specifies whether this is a bundle with 3 commands or 1 command and write data */
	tick_t start_time;

};

