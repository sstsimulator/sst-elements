#ifndef UPDATEINTERFACE__H
#define UPDATEINTERFACE__H


class UpdateInterface {
public:
	virtual void update(int) = 0;

};

#endif
