

//enable flags - comment these out to disable debugging for specified parts
#define EN_DEBUG
//#define DEBUG_NIC
//#define DEBUG_ROUTER
//#define DEBUG_XBAR
//#define DEBUG_APP
//#define DEBUG_PROCESSOR
//#define DEBUG_CACHE
//#define DEBUG_BUFFER
//#define DEBUG_OPTICS
//#define DEBUG_WIRES
//#define DEBUG_INIT
//#define DEBUG_DRAM
//#define DEBUG_FINISH
//#define DEBUG_DESTRUCT
//#define DEBUG_PATH_SETUP
//#define DEBUG_POWER
//#define DEBUG_PATH
