


class PowerMeasure {



public:

	PowerMeasure(){};

	float p_ACT;
	float CKE_LO_PRE;
	float CKE_LO_ACT;
	float t_ACT;
	float BNK_PRE;
	float p_PRE_PDN;
	float p_PRE_STBY;
	float p_PRE_MAX;
	float p_ACT_PDN;
	float p_ACT_STBY;
	float p_ACT_MAX;
	float WR_percent;
	float RD_percent;
	float p_WR;
	float p_RD;
	float p_DQ;
	float p_REF;
	float p_TOT;
	float p_TOT_MAX;
	float p_AMB_ACT;
	float p_AMB_PASS_THROUGH;
	float p_AMB_IDLE;
	float p_AMB;


};

